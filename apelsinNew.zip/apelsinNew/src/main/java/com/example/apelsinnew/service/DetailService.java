package com.example.apelsinnew.service;

import com.example.apelsinnew.entity.Detail;
import com.example.apelsinnew.payload.ApiResponse;
import com.example.apelsinnew.payload.DetailDto;
import com.example.apelsinnew.repository.DetailRepository;
import com.example.apelsinnew.repository.OrderRepository;
import com.example.apelsinnew.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class DetailService {

}
