package com.example.apelsinnew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApelsinNewApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApelsinNewApplication.class, args);
    }

}
